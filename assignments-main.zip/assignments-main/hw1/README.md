
Homework 1
