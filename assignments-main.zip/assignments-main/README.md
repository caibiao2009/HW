# assignments

This repo contains the starter notebooks for assignments in CMPS6730.


