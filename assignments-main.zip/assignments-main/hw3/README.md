
Homework 3
