# this pulls latest changes from template repo
# first line only need the first time this is run
git remote add template https://github.com/tulane-cmps6730/assignments
git fetch template
git merge template/main
